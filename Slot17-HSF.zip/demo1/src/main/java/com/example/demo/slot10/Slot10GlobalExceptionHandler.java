package com.example.demo.slot10;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
@ControllerAdvice
public class Slot10GlobalExceptionHandler {
    @ExceptionHandler(Slot10ResourceNotFoundException.class)
    public String handleNotFound(Slot10ResourceNotFoundException ex, Model model) {
        model.addAttribute("message", ex.getMessage());
        return "slot10/not-found";
    }
}
