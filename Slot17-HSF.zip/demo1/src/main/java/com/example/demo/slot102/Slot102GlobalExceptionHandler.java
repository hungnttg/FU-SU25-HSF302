package com.example.demo.slot102;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class Slot102GlobalExceptionHandler {
    @ExceptionHandler(Slot102ResourceNotFoundException.class)
    public String handleNotFound(Slot102ResourceNotFoundException e, Model model) {
        model.addAttribute("message", e.getMessage());
        return "slot102/sl102-not-found";

    }
}
