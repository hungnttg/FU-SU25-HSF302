package com.example.demo.slot102;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
@RequestMapping("/slot102/products")
public class Slot102ProductController {
    @Autowired
    private Slot102ProductRepository repo;
    @GetMapping("/search")
    public String search(@RequestParam(required = false) String keyword, Model model) {
        //xu ly bat loi
        List<Slot102Product> results = keyword != null && !keyword.isEmpty() ?
                repo.findByNameContaining(keyword) //neu co san pham
                : List.of();//tra ve rong neu nguoi dung khong nhap gi
        //dua ket qua va keyword vao model
        model.addAttribute("keyword", keyword);
        model.addAttribute("results", results);
        return "slot102/sl102-products-search";
    }
    @GetMapping("/{id}")
    public String getProductById(@PathVariable Long id, Model model) {
        //tim kiem san pham va tra ve loi
        Slot102Product product = repo.findById(id)
                .orElseThrow(()->
                        new Slot102ResourceNotFoundException("Khong tim thay san pham co ID="+id));
        //dua content vao model
        model.addAttribute("product", product);
        return "slot102/slot102-product-detail"; //tra ve trang detail
    }
//    cach goi:
//    http://localhost:8083/slot102/products/search
//    http://localhost:8083/slot102/products/1
//    http://localhost:8083/slot102/products/1000
}
