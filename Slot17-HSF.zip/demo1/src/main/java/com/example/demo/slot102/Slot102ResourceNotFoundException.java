package com.example.demo.slot102;

public class Slot102ResourceNotFoundException extends RuntimeException {
    public Slot102ResourceNotFoundException(String message) {
        super(message);
    }
}
