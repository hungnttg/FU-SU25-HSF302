package com.example.demo.slot10_1;

import com.example.demo.slot9.Sl9Product;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface Slot101ProductRepo extends JpaRepository<Slot101Product, Long> {
    // Tìm kiếm không phân trang
    List<Slot101Product> findByNameContaining(String keyword);
}
