package com.example.demo.slot10_1;

public class Slot101ResourceNotFountException extends RuntimeException {
    public Slot101ResourceNotFountException(String message) {
        super(message);
    }
}
