package com.example.demo.slot11;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/slot11/users")
public class Slot11UserController {

    @Autowired
    private UserRepository userRepo;

    @GetMapping("/register")
    public String showForm(Model model) {
        model.addAttribute("user", new User());
        return "slot11/user-form";
    }

    @PostMapping("/register")
    public String submitForm(@Valid @ModelAttribute("user") User user,
                             BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "slot11/user-form";
        }
        userRepo.save(user); // lưu vào DB!
        model.addAttribute("message",
                "Đăng ký thành công cho: " + user.getName());
        return "slot11/user-success";
    }
}
