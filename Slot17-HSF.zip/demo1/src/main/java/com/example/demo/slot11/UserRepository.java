package com.example.demo.slot11;

import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {
    // có thể thêm phương thức tìm kiếm nếu muốn
}
