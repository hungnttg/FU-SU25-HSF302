package com.example.demo.slot111;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Slot111UserRepository extends JpaRepository<Slot111User, Long> {

}
