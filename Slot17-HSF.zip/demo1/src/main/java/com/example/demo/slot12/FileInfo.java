package com.example.demo.slot12;

public class FileInfo {
    private String filename;
    private String url;

    public FileInfo(String filename, String url) {
        this.filename = filename;
        this.url = url;
    }

    public String getFilename() {
        return filename;
    }

    public String getUrl() {
        return url;
    }
}
