package com.example.demo.slot13;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/slot13")
public class Slot13UploadController {
    //http://localhost:8083/slot13/upload :upload
    //http://localhost:8083/slot13/files    : hien thi danh sach
    @Value("${upload.dir}")
    private String uploadDir; //khai bao thu muc upload
    @GetMapping("/upload")
    public String showForm(){
        return "slot13/uploadForm";
    }
    @PostMapping("/upload")
    public String handleFileUpload(@RequestParam("file") MultipartFile file,
                                   Model model) throws IOException {
        if(file.isEmpty()){//khi nguoi dung click upload ma khong co file
            model.addAttribute("message", "Chon file de upload");
            return "slot13/uploadForm";
        }
        //lay ve ten file
        String fileName = StringUtils.cleanPath(file.getOriginalFilename());
        Path savePath = Paths.get(uploadDir, fileName);//chuan bi duong dan
        //copy va cho phep ghi de
        Files.copy(file.getInputStream(), savePath, StandardCopyOption.REPLACE_EXISTING);
        //add vao model
        model.addAttribute("message", "Da upload thanh cong: "+fileName);
        return "slot13/uploadForm";//hien thi form
    }
        //hien thi
    @GetMapping("/files")
    public String listFiles(Model model) throws IOException {
        List<FileInfo> files = new ArrayList<>();//mang chua file
        //doc du lieu tu thu muc
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(Paths.get(uploadDir))) {
            for(Path path : stream){
                String fileName = path.getFileName().toString();
                files.add(new FileInfo(fileName,"/uploads/"+fileName));
            }
        }
        //dua vao model
        model.addAttribute("files", files);
        return "slot13/uploadList"; //tra ve file html

    }
}
