package com.example.demo.slot14;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Controller
public class Slot14PostController {

    @Autowired
    @Qualifier("restTemplateSlot14")
    private RestTemplate restTemplate;
    //goi: http://localhost:8083/slot14/posts
    @GetMapping("/slot14/posts")
    public String listPosts(Model model) {
        try {
            // Gọi API public lấy danh sách bài viết mẫu
            String apiUrl = "https://jsonplaceholder.typicode.com/posts";
            Post[] posts = restTemplate.getForObject(apiUrl, Post[].class);
            model.addAttribute("posts", posts);
        } catch (RestClientException e) {
            model.addAttribute("error",
                    "Không thể tải dữ liệu bài viết bên ngoài.");
        }
        return "slot14/post-list";
    }
}