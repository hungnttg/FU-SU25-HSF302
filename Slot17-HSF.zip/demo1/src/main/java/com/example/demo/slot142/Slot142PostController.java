package com.example.demo.slot142;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Controller
public class Slot142PostController {
    private List<Post> postCache = new ArrayList<>();
    @Autowired
    @Qualifier("restTemplateSlot142")
    private RestTemplate restTemplate;
    //http://localhost:8083/slot142/posts
    @GetMapping("/slot142/posts")
    public String posts(Model model) {
        try {
            //goi API
            String apiUrl="https://jsonplaceholder.typicode.com/posts";
            //tao mang luu tru bai viet
            Post[] posts = restTemplate.getForObject(apiUrl, Post[].class);
            if(posts != null) {
                postCache = List.of(posts);//dua cac bai viet truy van vao cache
            }
            //add vao model
            model.addAttribute("posts", posts);
        } catch (RestClientException e){
            model.addAttribute("error", "Khong the tai du lieu");
        }
        return "slot142/post-list";
    }
    //xoa cache
    @GetMapping("/slot142/posts/reload")
    public String reload() {
        postCache.clear();
        return "redirect:/slot142/post-list";
    }
}
