package com.example.demo.slot17;

import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@Controller
@RequestMapping("/slot17/products")
public class Slot17ProductController {
    @Autowired
    private Slot17ProductService productService;

    @GetMapping
    public String list(Model model) {
        model.addAttribute("products", productService.findAll());
        return "slot17/product-list";
    }

    @GetMapping("/export")
    public void exportCSV(HttpServletResponse response) throws IOException {
        response.setContentType("text/csv");
        response.setHeader("Content-Disposition",
                "attachment; filename=products.csv");

        List<Product> products = productService.findAll();

        PrintWriter writer = response.getWriter();
        writer.println("ID,Name,Price");

        for (Product p : products) {
            writer.println(p.getId() + "," + p.getName() + "," + p.getPrice());
        }

        writer.flush();
    }
}
