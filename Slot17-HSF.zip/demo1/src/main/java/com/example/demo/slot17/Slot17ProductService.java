package com.example.demo.slot17;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class Slot17ProductService {
    private final List<Product> productList = new ArrayList<>();
    public Slot17ProductService() {
        productList.add(new Product(1L, "iPhone 15", 25000000));
        productList.add(new Product(2L, "Samsung S24", 20000000));
    }
    public List<Product> findAll() {
        return productList;
    }
}
