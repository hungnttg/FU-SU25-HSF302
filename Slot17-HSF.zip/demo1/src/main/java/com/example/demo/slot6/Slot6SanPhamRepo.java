package com.example.demo.slot6;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Slot6SanPhamRepo extends JpaRepository<Slot6SanPham, Integer> {
}
