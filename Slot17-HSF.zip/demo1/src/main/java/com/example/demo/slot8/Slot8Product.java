package com.example.demo.slot8;

import jakarta.persistence.*;

@Entity
@Table(name = "slot8_product")
public class Slot8Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;   // phải có trường này

    private String name;
    private String description;
    private Double price;

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    // getter cho id
    public Long getId() {
        return id;
    }
    // setter cho id
    public void setId(Long id) {
        this.id = id;
    }

    // getter/setter cho name, price
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Double getPrice() {
        return price;
    }
    public void setPrice(Double price) {
        this.price = price;
    }
}
