package com.example.demo.slot8;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/slot8/products")
public class Slot8ProductController {
    private final Slot8ProductService productService;

    public Slot8ProductController(Slot8ProductService productService) {
        this.productService = productService;
    }

    // Danh sách sản phẩm
    @GetMapping
    public String listProducts(Model model) {
        model.addAttribute("products",
                productService.getAllProducts());
        return "slot8/product-list";
    }

    // Form thêm sản phẩm mới
    @GetMapping("/new")
    public String showCreateForm(Model model) {
        Slot8Product product = new Slot8Product();  // Tạo mới object trống
        model.addAttribute("product", product);    // Đưa vào model
        return "slot8/product-form";
    }


    // Lưu sản phẩm (thêm hoặc sửa)
    @PostMapping("/save")
    public String saveProduct(@ModelAttribute("product") Slot8Product product,
                              RedirectAttributes redirectAttrs) {
        productService.saveProduct(product);
        redirectAttrs.addFlashAttribute("message",
                "Lưu sản phẩm thành công!");
        return "redirect:/slot8/products";
    }

    // Form sửa sản phẩm
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model,
                               RedirectAttributes redirectAttrs) {
        var productOpt = productService.getProductById(id);
        if (productOpt.isPresent()) {
            model.addAttribute("product", productOpt.get());
            return "slot8/product-form";
        } else {
            redirectAttrs.addFlashAttribute("error",
                    "Sản phẩm không tồn tại!");
            return "redirect:/slot8/products";
        }
    }

    // Xóa sản phẩm
    @GetMapping("/delete/{id}")
    public String deleteProduct(@PathVariable Long id,
                                RedirectAttributes redirectAttrs) {
        productService.deleteProduct(id);
        redirectAttrs.addFlashAttribute("message",
                "Đã xóa sản phẩm!");
        return "redirect:/slot8/products";
    }
    /*
    truy cập /slot8/products để xem danh sách sản phẩm.

/slot8/products/new để thêm mới.

/slot8/products/edit/{id} để sửa.

/slot8/products/delete/{id} để xóa.


    * */
}