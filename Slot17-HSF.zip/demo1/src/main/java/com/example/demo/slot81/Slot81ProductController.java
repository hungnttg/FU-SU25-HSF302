package com.example.demo.slot81;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("slot81/products")
public class Slot81ProductController {
    private final Slot81ProductService productService;
    public Slot81ProductController(Slot81ProductService productService) {
        this.productService = productService;
    }
    //danh sach san pham
    @GetMapping
    public String listProducts(Model model) {
        model.addAttribute("products",productService.getAllProducts());
        return "slot81/product81-list";
    }
    //form them san pham moi
    @GetMapping("/new")
    public String showCreateForm(Model model) {
        Slot81Product product = new Slot81Product();//tao moi 1 objec
        model.addAttribute("product",product);//gan vao model
        return "slot81/product81-form";
    }
    //luu san pham (them, sua)
    @PostMapping("/save")
    public String saveProduct(@ModelAttribute("product") Slot81Product product,
                              RedirectAttributes redirectAttr) {
        productService.saveProduct(product);//luu
        //dua ra thong bao thanh cong
        redirectAttr.addFlashAttribute("message","Product saved successfully");
        //redirect ve trang listproduct
        return "redirect:/slot81/products";
    }
    //form sua san pham
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model,RedirectAttributes redirectAttr) {
        var productOpt = productService.getProductById(id);//lay ve 1 san pham can sua
        if (productOpt.isPresent()) {//neu ton tai san pham
            model.addAttribute("product",productOpt.get());
            return "slot81/product81-form";
        } else {//neu khong ton tai san pham
            redirectAttr.addFlashAttribute("error","Product not found");
            return "redirect:/slot81/products";
        }
    }
    //xoa san pham
    @GetMapping("/delete/{id}")
    public String deleteProduct(@PathVariable("id") long id, RedirectAttributes redirectAttr) {
        productService.deleteProductById(id);//xoa san pham
        //thong bao thanh cong
        redirectAttr.addFlashAttribute("message","Product deleted successfully");
        return "redirect:/slot81/products";//redirect ve listproduct
    }
    //cach goi
    //truy cap /slot81/products: danh sach san pham
    //slot81/products/new: them moi
    //slot81/products/edit/{id}: sua
    //slot81/products/delete/{id}: xoa
}
