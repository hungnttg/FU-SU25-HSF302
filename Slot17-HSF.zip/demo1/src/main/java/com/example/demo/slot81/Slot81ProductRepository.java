package com.example.demo.slot81;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Slot81ProductRepository extends JpaRepository<Slot81Product, Long> {

}
