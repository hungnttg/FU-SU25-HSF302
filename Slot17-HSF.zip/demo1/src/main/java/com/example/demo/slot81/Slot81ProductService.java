package com.example.demo.slot81;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class Slot81ProductService {
    private final Slot81ProductRepository repository;//tham chieu den repo
    //ham khoi tao
    public Slot81ProductService(Slot81ProductRepository repository) {
        this.repository = repository;
    }
    //get all san pham
    public List<Slot81Product> getAllProducts() {
        return repository.findAll();//lay tat ca cac san pham
    }
    //lay 1 san pham theo ID
    public Optional<Slot81Product> getProductById(Long id) {
        return repository.findById(id);
    }
    //luu 1 san pham vao db
    public Slot81Product saveProduct(Slot81Product product) {
        return repository.save(product);
    }
    //xoa 1 san pham
    public void deleteProductById(Long id) {
        repository.deleteById(id);
    }
}
