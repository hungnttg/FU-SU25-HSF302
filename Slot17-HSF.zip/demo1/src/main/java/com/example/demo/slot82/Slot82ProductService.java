package com.example.demo.slot82;

import jakarta.persistence.Entity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class Slot82ProductService {
    //tham chieu den repo
    private final Slot82ProductRepository productRepository;
    //ham khoi tao
    public Slot82ProductService(Slot82ProductRepository productRepository) {
        this.productRepository = productRepository;
    }
    //lay tat ca san pham
    public List<Slot82Product> getAllProducts() {
        return productRepository.findAll();
    }
    //lay san pham theo id
    public Optional<Slot82Product> getProductById(Long id) {
        return productRepository.findById(id);
    }
    //luu san pham
    public Slot82Product saveProduct(Slot82Product product) {
        return productRepository.save(product);
    }
    //delete product
    public void deleteProductById(Long id) {
        productRepository.deleteById(id);
    }
}
