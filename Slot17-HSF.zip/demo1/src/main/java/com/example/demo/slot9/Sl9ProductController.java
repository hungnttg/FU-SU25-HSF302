package com.example.demo.slot9;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/products")
public class Sl9ProductController {
    @Autowired
    private Sl9ProductRepository productRepo;
    // Lấy theo ID (PathVariable)
    @GetMapping("/{id}")
    public ResponseEntity<Sl9Product> getById(@PathVariable Long id) {
        return productRepo.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    // Tìm kiếm sản phẩm theo tên (RequestParam)
    @GetMapping("/search")
    public List<Sl9Product> search(@RequestParam String keyword) {
        return productRepo.findByNameContaining(keyword);
    }

    // Tìm kiếm có phân trang (RequestParam nâng cao)
    @GetMapping("/searchPage")
    public Page<Sl9Product> searchPaging(@RequestParam String keyword,
                                         @RequestParam(defaultValue = "0") int page,
                                         @RequestParam(defaultValue = "5") int size) {
        return productRepo.findByNameContaining(keyword, PageRequest.of(page, size));
    }
}
/*
    GET /products/1	Lấy sản phẩm có ID = 1
GET /products/search?keyword=apple	Tìm sản phẩm có tên chứa "apple"
GET /products/searchPage?keyword=tv&page=1&size=2	Tìm kiếm có phân trang
------bai tap cho sinh vien----
Viết một controller hiển thị thông tin sinh viên theo @PathVariable.

Viết API tìm kiếm sinh viên theo tên, mã sinh viên bằng @RequestParam.

Nâng cao: dùng @RequestParam để phân trang danh sách sinh viên.
* */