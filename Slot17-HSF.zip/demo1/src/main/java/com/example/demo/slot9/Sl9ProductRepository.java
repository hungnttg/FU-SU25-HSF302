package com.example.demo.slot9;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface Sl9ProductRepository extends JpaRepository<Sl9Product, Long> {

    // Tìm kiếm không phân trang
    List<Sl9Product> findByNameContaining(String keyword);

    // Tìm kiếm có phân trang
    Page<Sl9Product> findByNameContaining(String keyword, Pageable pageable);
}
