package com.example.demo.slot9;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/web/products")
public class Sl9ProductWebController {

    @Autowired
    private Sl9ProductRepository productRepo;

    @GetMapping("/searchPage")
    public String searchPaging(@RequestParam String keyword,
                               @RequestParam(defaultValue = "0") int page,
                               @RequestParam(defaultValue = "5") int size,
                               Model model) {

        Page<Sl9Product> result =
                productRepo.findByNameContaining(keyword, PageRequest.of(page, size));
        model.addAttribute("products", result.getContent());
        return "slot9/sl9-product-search";
//        http://localhost:8083/web/products/searchPage?keyword=tv
    }
}

