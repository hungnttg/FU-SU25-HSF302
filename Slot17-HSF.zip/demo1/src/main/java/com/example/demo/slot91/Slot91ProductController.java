package com.example.demo.slot91;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/sl91/products")
public class Slot91ProductController {
    @Autowired
    private Slot91ProductRepository repo;
    //lay theo ID (PathVariable)
    @GetMapping("/{id}")
    public ResponseEntity<Slot91Product> getById(@PathVariable Long id) {
        return repo.findById(id)//tim kiem theo id
                .map(ResponseEntity::ok)//neu tra ve
                .orElse(ResponseEntity.notFound().build());//khong tra ve
    }
    //tim kiem san pham theo ten (RequestParam)
    @GetMapping("/search")
    public List<Slot91Product> search(@RequestParam String keyword) {
        return repo.findByNameContaining(keyword);//implement ham trong interface
    }
    //tim kiem cos phan trang (RequestParam)
    @GetMapping("/searchPage")
    public Page<Slot91Product> searchPaging(@RequestParam String keyword,
                                            @RequestParam(defaultValue = "0") int page,
                                            @RequestParam(defaultValue = "5") int size){
        return repo.findByNameContaining(keyword, PageRequest.of(page, size));
    }
    //cach goi: http://localhost:8083/sl91/products/1 : lay ve san pham co id la 1
    //http://localhost:8083/sl91/products/search?keyword=ten : tim kiem khong phan trang
    //http://localhost:8083/sl91/products/searchPage?keyword=ten&page=1&size=2
}
