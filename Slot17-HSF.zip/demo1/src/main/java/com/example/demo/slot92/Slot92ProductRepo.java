package com.example.demo.slot92;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface Slot92ProductRepo extends JpaRepository<Slot92Product, Long> {
    //khai bao cac phuong thuc can xu ly trong interface
    //tim kiem khong phan trang
    List<Slot92Product> findByNameContaining(String keyword);
    //tim kiem co phan trang
    Page<Slot92Product> findByNameContaining(String keyword, Pageable pageable);
}
