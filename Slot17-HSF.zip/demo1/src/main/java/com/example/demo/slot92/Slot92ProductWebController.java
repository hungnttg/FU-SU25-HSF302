package com.example.demo.slot92;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/web/slot92/products")
public class Slot92ProductWebController {
    @Autowired
    private Slot92ProductRepo repo;
    //tim kiem san pham co phan trang
    @GetMapping("/searchPage")
    public String searchPage(@RequestParam String keyword,
                             @RequestParam(defaultValue = "0") int page,
                             @RequestParam(defaultValue = "5") int size, Model model) {
        //implement ham trong interface
        Page<Slot92Product> result= repo.findByNameContaining(keyword, PageRequest.of(page, size));
        //dua vao model de chuyen du lieu sang client
        model.addAttribute("products", result.getContent());
        return "slot92/sl92-search-product";//goi client

    }
}
