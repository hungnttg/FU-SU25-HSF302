# AppLock

Ứng dụng khóa ứng dụng, hình ảnh, video và bảo vệ quyền riêng tư cho Android.

## Chức năng chính
- Khóa ứng dụng (Facebook, WhatsApp, Gallery, Messenger, Snapchat, Instagram, SMS, Contacts, Gmail, Settings, cuộc gọi đến, v.v.)
- Khóa hình ảnh và video, ẩn khỏi thư viện, chỉ xem được trong vault
- Bàn phím ngẫu nhiên và khóa mẫu vô hình
- Bảo vệ gỡ cài đặt (Advanced Protection, Device Administrator)
- Khôi phục mật khẩu qua email hoặc câu hỏi bảo mật
- Sử dụng Accessibility Service để khóa app
- Đa ngôn ngữ
- Ẩn icon AppLock, mở bằng nhiều cách đặc biệt
- Quảng cáo và mua hàng trong ứng dụng

## Roadmap phát triển
1. Khởi tạo project Android (Kotlin)
2. Thiết lập các dependency cơ bản
3. Thiết kế UI màn hình chào, thiết lập mật khẩu
4. Danh sách ứng dụng, chọn app để khóa
5. Khóa ứng dụng bằng Accessibility Service
6. Khóa/ẩn hình ảnh, video (Vault)
7. Ẩn icon AppLock & mở bằng nhiều cách đặc biệt
8. Bảo vệ gỡ cài đặt (Device Admin)
9. Bàn phím ngẫu nhiên & khóa mẫu vô hình
10. Đa ngôn ngữ
11. Quảng cáo & mua hàng trong ứng dụng
12. Giao diện đẹp, dễ dùng 