package com.example.demo;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import java.awt.*;
import java.net.URI;

@Component
public class WebRunner implements ApplicationRunner {
    @Override
    public void run(ApplicationArguments args) throws Exception {
        String url = "http://localhost:8083/slot18/email/send";
        if(Desktop.isDesktopSupported()) {
            Desktop desktop = Desktop.getDesktop();
            if(desktop.isSupported(Desktop.Action.BROWSE)) {
                desktop.browse(new URI(url));
            } else {
                System.out.println("Desktop is not supported");
            }
        }
        else {
            System.out.println("Desktop is not supported");
        }
        //xac dinh he dieu hanh
        String os = System.getProperty("os.name").toLowerCase();
        if(os.contains("win")) {
            Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + url);
        }
        else if(os.contains("mac")) {
            Runtime.getRuntime().exec("open " + url);
        }
        else {
            System.out.println("OS is not supported");
        }
    }
}
