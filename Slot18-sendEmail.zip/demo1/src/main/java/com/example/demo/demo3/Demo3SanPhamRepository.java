package com.example.demo.demo3;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Demo3SanPhamRepository extends JpaRepository<Demo3SanPham, Integer> {
}
