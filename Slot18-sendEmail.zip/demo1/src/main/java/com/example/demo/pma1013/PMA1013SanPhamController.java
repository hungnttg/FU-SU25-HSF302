package com.example.demo.pma1013;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/pma1013")
public class PMA1013SanPhamController {
    @Autowired
    private PMA101SanPhamRepository repo;//tham chieu den repo
    @GetMapping("/list")//http://localhost:8083/pma1013/list
    public String getlist(Model model) {
        List<PMA1013SanPham> list = repo.findAll();//lay toan bo san pham
        model.addAttribute("list", list);//dua vao model
        return "pma1013/list-sanpham";
    }

}
