package com.example.demo.pma1013;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PMA101SanPhamRepository extends JpaRepository<PMA1013SanPham, Integer> {

}
