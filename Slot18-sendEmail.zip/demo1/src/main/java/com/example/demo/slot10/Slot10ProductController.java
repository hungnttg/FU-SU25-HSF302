package com.example.demo.slot10;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/slot10/products")
public class Slot10ProductController {

    @Autowired
    private Slot10ProductRepository productRepo;

    @GetMapping("/search")
    public String search(@RequestParam(required = false) String keyword, Model model) {
        List<Slot10Product> results = keyword != null && !keyword.isBlank()
                ? productRepo.findByNameContaining(keyword)
                : List.of(); // Trả về rỗng nếu chưa nhập gì

        model.addAttribute("keyword", keyword);
        model.addAttribute("results", results);
        return "slot10/slot10-product-search";
    }

    @GetMapping("/{id}")
    public String getProductById(@PathVariable Long id, Model model) {
        Slot10Product product = productRepo.findById(id)
                .orElseThrow(() ->
         new Slot10ResourceNotFoundException("Không tìm thấy sản phẩm có ID = " + id));
        model.addAttribute("product", product);
        return "slot10/product-detail";
    }
//    tim kiem: http://localhost:8083/slot10/products/search
//    http://localhost:8083/slot10/products/1
//    http://localhost:8083/slot10/products/2
    //http://localhost:8083/slot10/products/999
}

