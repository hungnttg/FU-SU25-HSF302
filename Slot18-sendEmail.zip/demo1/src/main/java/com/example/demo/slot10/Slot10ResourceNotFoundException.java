package com.example.demo.slot10;

public class Slot10ResourceNotFoundException extends RuntimeException{
    public Slot10ResourceNotFoundException(String message) {
        super(message);
    }
}
