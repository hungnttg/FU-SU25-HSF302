package com.example.demo.slot102;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface Slot102ProductRepository extends JpaRepository<Slot102Product, Long> {
    //tim kiem khong phan trang
    List<Slot102Product> findByNameContaining(String keyword);
}
