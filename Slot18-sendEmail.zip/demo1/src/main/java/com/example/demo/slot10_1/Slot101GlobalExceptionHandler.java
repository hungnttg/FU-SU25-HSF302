package com.example.demo.slot10_1;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class Slot101GlobalExceptionHandler {
    @ExceptionHandler(Slot101ResourceNotFountException.class)
    public String handleNotFound(Slot101ResourceNotFountException e, Model model) {
        model.addAttribute("message", e.getMessage());
        return "slot101/sl101-not-found";
    }
}
