package com.example.demo.slot111;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
public class Slot111User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Ten khong duoc de trong")
    @Size(min = 2, message = "Ten phai co it nhat 2 ky tu")
    private String name;

    @Min(value = 18,message = "Tuoi phai tu 18 tro len")
    @Max(value = 99,message = "Tuoi phai nho hon 99")
    private int age;

    @Email(message = "Email khong hop le")
    private String email;

    public Slot111User() {
    }

    public Slot111User(Long id, String name, int age, String email) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.email = email;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
