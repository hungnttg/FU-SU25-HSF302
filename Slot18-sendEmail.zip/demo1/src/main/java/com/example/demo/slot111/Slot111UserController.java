package com.example.demo.slot111;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/slot11/sl11user")
public class Slot111UserController {
    @Autowired
    private Slot111UserRepository repo;
    @GetMapping("/register")
    public String showForm(Model model) {
        model.addAttribute("user", new Slot111User());
        return "slot111/sl11-user-form";
    }
    @PostMapping("/register")
    public String submitForm(@Valid @ModelAttribute("user") Slot111User user,
                             BindingResult result, Model model) {
        if (result.hasErrors()) {//neu xay ra loi
            return "slot111/sl11-user-form";//tra ve form cu
        }
        repo.save(user);//luu du lieu neu khong loi
        model.addAttribute("message","Dang ky thanh cong "
                +user.getName());
        return "slot111/sl11-user-success";//tra ve form dang ky thanh cong
    }
//    goi:
//    http://localhost:8083/slot11/sl11user/register
}
