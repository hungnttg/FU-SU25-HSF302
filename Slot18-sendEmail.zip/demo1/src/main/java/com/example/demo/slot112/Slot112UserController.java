package com.example.demo.slot112;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/slot112/users")
public class Slot112UserController {
    @Autowired
    private Slot112UserRepo repo;
//    dang ky tai khoan
    @GetMapping("/register")
    public String register(Model model) {
        //tao 1 doi tuong user va gan vao model
        model.addAttribute("user", new Slot112User());
        return "slot112/sl112-register";
    }
// validate, neu thanh cong se cho phep dang ky va luu user vao DB
    @PostMapping("/register")
    public String submitForm(@Valid @ModelAttribute("user") Slot112User user,
                             BindingResult result, Model model) {
       if (result.hasErrors()) {//neu co loi thi hien thi form cho nguoi dung nhap lai
           return "slot112/sl112-register";
       }
       repo.save(user);//luu vao csdl
        model.addAttribute("message", "Dang ky thanh cong "+user.getName());
        return "slot112/sl112-success";
    }
}
