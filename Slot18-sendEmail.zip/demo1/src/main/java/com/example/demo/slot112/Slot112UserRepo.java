package com.example.demo.slot112;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Slot112UserRepo extends JpaRepository<Slot112User, Long> {

}
