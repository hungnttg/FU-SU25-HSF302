package com.example.demo.slot12;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.nio.file.*;
import java.util.*;
/*
Kết quả:
http://localhost:8080/slot12/upload để chọn và upload file.

File sẽ lưu vào thư mục uploads/ trên server.

http://localhost:8080/slot12/files để xem danh sách và tải file.
* */
@Controller
@RequestMapping("/slot12")
public class Slot12UploadController {

    @Value("${upload.dir}")
    private String uploadDir;

    @GetMapping("/upload")
    public String showForm() {
        return "slot12/upload-form";
    }

    @PostMapping("/upload")
    public String handleUpload(@RequestParam("file") MultipartFile file,
                               Model model) throws IOException {
        if (file.isEmpty()) {
            model.addAttribute("message",
                    "Chọn file để upload");
            return "slot12/upload-form";
        }

        String filename = StringUtils.cleanPath(file.getOriginalFilename());
        Path savePath = Paths.get(uploadDir, filename);
        Files.copy(file.getInputStream(), savePath,
                StandardCopyOption.REPLACE_EXISTING);

        model.addAttribute("message",
                "Đã upload thành công: " + filename);
        return "slot12/upload-form";
    }

    @GetMapping("/files")
    public String listFiles(Model model) throws IOException {
        List<FileInfo> files = new ArrayList<>();

        try (DirectoryStream<Path> stream =
                     Files.newDirectoryStream(Paths.get(uploadDir))) {
            for (Path path : stream) {
                String filename = path.getFileName().toString();
                files.add(new FileInfo(filename, "/uploads/"
                        + filename));
            }
        }

        model.addAttribute("files", files);
        return "slot12/upload-list";
    }
}
