package com.example.demo.slot131;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

@Controller
@RequestMapping("/slot131")
public class Slot131UploadController {
    //upload
    //http:localhost:8083/slot131/upload
    //doc file upload trong thu muc
    //http:localhost:8083/slot131/files
    @Value("${upload.dir}")
    private String uploadDir;//khai bao thu muc upload
//    hien thi form upload
    @GetMapping("/upload")
    public String showForm(){
        return "slot131/upload-form";
    }
//    thuc hien upload
    @PostMapping("/upload")
    public String handleFileUpload(@RequestParam("file") MultipartFile file,
                                   Model model) throws IOException {
        if (file.isEmpty()) { //neu nguoi dung khong tryen file
            model.addAttribute("message", "Please select a file to upload");
            return "slot131/upload-form";//tro ve form cu
        }
        //neu nguoi dung da truyen file
        String fileName = StringUtils.cleanPath(file.getOriginalFilename());//lay ve ten file
        Path savePath = Paths.get(uploadDir,fileName);//lay ve duong dan
        //upload len thu muc, cho phep replace neu da ton tai
        Files.copy(file.getInputStream(), savePath, StandardCopyOption.REPLACE_EXISTING);
        //dua vao model
        model.addAttribute("message", "File uploaded successfully "+fileName);
        return "slot131/upload-form";//tra ve form
    }
//    liet ke cac file upload
    @GetMapping("/files")
    public String showFiles(Model model) throws IOException {
        List<FileInfo> files = new ArrayList<>();//tao list chua cac file
        //doc tu thu muc
        try (DirectoryStream<Path> directoryStream = Files.newDirectoryStream(Paths.get(uploadDir))) {
            for(Path path : directoryStream) {
                //lay ve cac ten file doc duc
                String fileName = path.getFileName().toString();
                //them vao danh sach
                files.add(new FileInfo(fileName,"/uploads/"+fileName));
            }
        }
        model.addAttribute("files", files);//them danh sach file vao model
        return "slot131/upload-list"; //tra ve trang co list file
    }

}
