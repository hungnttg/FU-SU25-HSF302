package com.example.demo.slot14;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class Slot14Config {
    @Bean(name = "restTemplateSlot14")
    public RestTemplate restTemplateSlot14() {
        return new RestTemplate();
    }
}