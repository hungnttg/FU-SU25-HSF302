package com.example.demo.slot141;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class Slot141Config {
    @Bean(name = "restTemplateSlot141")
    public RestTemplate restTemplateSlot141() {
        return new RestTemplate();
    }
}
