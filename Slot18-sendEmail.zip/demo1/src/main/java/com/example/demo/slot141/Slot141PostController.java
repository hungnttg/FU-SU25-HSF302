package com.example.demo.slot141;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Controller
public class Slot141PostController {
    @Autowired
    @Qualifier("restTemplateSlot141")
    private RestTemplate restTemplate;
    //goi: http://localhost:8083/slot141/posts
    @GetMapping("/slot141/posts")
    public String posts(Model model) {
        try {
            //goi API public lay danh sach bai viet
            String apiUrl = "https://jsonplaceholder.typicode.com/posts";
            //mang chua bai viet
            Post[] posts = restTemplate.getForObject(apiUrl, Post[].class);
            if(posts != null && posts.length > 0) {
                //đua du lieu vao cache
                postCache = List.of(posts);
            }
            //dua vao model
            model.addAttribute("posts", posts);
        } catch (RestClientException e) {
            // neu gap RestClientException   => chuyen loi qua view
            model.addAttribute("error", "Khong tai duoc du lieu");
        }
        return "slot141/post-list";
    }
//    ví dụ: xử lý cache
    private List<Post> postCache = new ArrayList<>();
    @GetMapping("/slot141/post/reload")
    public String reload() {
        postCache.clear();
        return "redirect: slot141/post-list";
    }
}
