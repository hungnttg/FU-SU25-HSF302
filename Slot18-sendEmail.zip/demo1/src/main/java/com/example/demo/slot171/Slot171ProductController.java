package com.example.demo.slot171;

import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@Controller
@RequestMapping("/slot171/products")
public class Slot171ProductController {
    @Autowired
    private Slot171ProductService slot171ProductService;
    @GetMapping
    public String getProducts(Model model) {
        model.addAttribute("products",slot171ProductService.findAll());
        return "slot171/product-list";
    }
    @GetMapping("/export")
    public void exportCSV(HttpServletResponse response) throws IOException {
        response.setContentType("text/csv");
        response.setHeader("Content-Disposition", "attachment; filename=\"products.csv\"");
        List<Product> products = slot171ProductService.findAll();
        PrintWriter printWriter = response.getWriter();
        printWriter.println("ID, Name, Price");
        for (Product product : products) {
            printWriter.println(product.getId() + "," + product.getName() + "," + product.getPrice());
        }
        printWriter.flush();
    }
}
