package com.example.demo.slot171;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class Slot171ProductService {
    private final List<Product> productList = new ArrayList<>();

    public Slot171ProductService() {
        //khoi tao cac san pham
        productList.add(new Product(1L,"iphone 16",30000.500));
        productList.add(new Product(2L,"iphone 17",40000.500));
    }
    public List<Product> findAll() {
        return productList;
    }
}
