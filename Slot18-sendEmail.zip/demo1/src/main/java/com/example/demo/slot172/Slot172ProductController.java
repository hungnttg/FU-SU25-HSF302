package com.example.demo.slot172;

import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@Controller
@RequestMapping("/slot172/products")
public class Slot172ProductController {
    @Autowired
    private Slot172ProductService slot172ProductService;
    @GetMapping
    public String getProducts(Model model) {
        model.addAttribute("products",slot172ProductService.getListProduct());
        return "slot172/product-list";
    }
    @GetMapping("/export")
    public void export(HttpServletResponse response) throws IOException {
        response.setContentType("text/csv");//set kieu
        //set file tai ve
        response.setHeader("Content-Disposition", "attachment; filename=products.csv");
        List<Product> products = slot172ProductService.getListProduct();//lay ve danh sach can export
        PrintWriter writer = response.getWriter();
        writer.println("id,name,price");
        for (Product product : products) {
            writer.println(product.getId() + "," + product.getName() + "," + product.getPrice());
        }
        writer.flush();
    }
}
