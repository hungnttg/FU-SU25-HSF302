package com.example.demo.slot172;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class Slot172ProductService {
    private final List<Product> listProduct = new ArrayList<>();

    public Slot172ProductService() {
        //doc du lieu tu API hoac add các san pham vao
        listProduct.add(new Product(1,"Iphone 16",111));
        listProduct.add(new Product(2,"iPhone 17",222));
    }
    //ham lay toan bo san pham
    public List<Product> getListProduct() {
        return listProduct;
    }
}
