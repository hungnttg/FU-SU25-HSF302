package com.example.demo.slot18;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/slot18/email")
public class Slot18EmailController {

    @Autowired
    private Slot18EmailService emailService;
    //http://localhost:8083/slot18/email/send
    @GetMapping("/send")
    public String showEmailForm() {
        return "slot18/email-form";
    }

    @PostMapping("/send")
    public String sendEmail(
            @RequestParam("to") String to,
            @RequestParam("subject") String subject,
            @RequestParam("body") String body,
            Model model) {

        emailService.sendEmail(to, subject, body);
        model.addAttribute("message",
                "Email đã được gửi thành công!");
        return "slot18/email-form";
    }
}
