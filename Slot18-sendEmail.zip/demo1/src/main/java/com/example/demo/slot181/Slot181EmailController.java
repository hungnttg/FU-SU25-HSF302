package com.example.demo.slot181;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/slot181/email")
public class Slot181EmailController {
    @Autowired
    private Slot181EmailService emailService;
    //htttp://localhost:8083/slot18/email/send
    @GetMapping("/send")
    public String showEmailForm() {
        return "slot181/email-form";
    }
    @PostMapping("/send")
    public String sendEmail(
            @RequestParam("to") String to,
            @RequestParam("subject") String subject,
            @RequestParam("body") String body,
            Model model
    ){
        emailService.sendEmail(to, subject, body);
        model.addAttribute("message", "Email sent successfully");
        return "slot181/email-form";
    }
}
