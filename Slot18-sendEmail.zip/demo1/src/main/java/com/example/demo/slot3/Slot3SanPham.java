package com.example.demo.slot3;

import jakarta.persistence.*;

@Entity //the hien day la 1 thuc the, tuong duong voi bang du lieu
@Table(name = "sanpham")//su dung bang co san trong sqlserver
public class Slot3SanPham {
    @Id //khoa chinh
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String tensanpham;
    private int giasanpham;
    private String hinhanhsanpham;
    private String motasanpham;
    private int idsanpham;

    public Slot3SanPham() {
    }

    public Slot3SanPham(int id, String tensanpham, int giasanpham, String hinhanhsanpham, String motasanpham, int idsanpham) {
        this.id = id;
        this.tensanpham = tensanpham;
        this.giasanpham = giasanpham;
        this.hinhanhsanpham = hinhanhsanpham;
        this.motasanpham = motasanpham;
        this.idsanpham = idsanpham;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTensanpham() {
        return tensanpham;
    }

    public void setTensanpham(String tensanpham) {
        this.tensanpham = tensanpham;
    }

    public int getGiasanpham() {
        return giasanpham;
    }

    public void setGiasanpham(int giasanpham) {
        this.giasanpham = giasanpham;
    }

    public String getHinhanhsanpham() {
        return hinhanhsanpham;
    }

    public void setHinhanhsanpham(String hinhanhsanpham) {
        this.hinhanhsanpham = hinhanhsanpham;
    }

    public String getMotasanpham() {
        return motasanpham;
    }

    public void setMotasanpham(String motasanpham) {
        this.motasanpham = motasanpham;
    }

    public int getIdsanpham() {
        return idsanpham;
    }

    public void setIdsanpham(int idsanpham) {
        this.idsanpham = idsanpham;
    }
}
