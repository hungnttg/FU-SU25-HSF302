package com.example.demo.slot3;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/sanpham")
public class Slot3SanPhamController {
    @Autowired
    private Slot3SanPhamRepository repository;
//    lay tat ca cac san pham
    @GetMapping
    public List<Slot3SanPham> getAll() {
        return repository.findAll();
    }
//    lay ve 1 san pham
    @GetMapping("/{id}")
    public Optional<Slot3SanPham> getById(@PathVariable Integer id) {
        return repository.findById(id);
    }
//    them moi 1 san pham
    @PostMapping
    public Slot3SanPham save(@RequestBody Slot3SanPham sanPham) {
        return repository.save(sanPham);
    }
//    cap nhat san pham
    @PutMapping("/{id}")
    public Slot3SanPham update(@PathVariable Integer id, @RequestBody Slot3SanPham sanPham) {
        sanPham.setId(id);
        return repository.save(sanPham);
    }
//    xoa san pham
    @DeleteMapping("/{id}")
    public void delete(@PathVariable Integer id) {
        repository.deleteById(id);
    }
}
