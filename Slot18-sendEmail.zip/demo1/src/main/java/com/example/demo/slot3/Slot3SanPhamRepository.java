package com.example.demo.slot3;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Slot3SanPhamRepository extends JpaRepository<Slot3SanPham, Integer> {
}
