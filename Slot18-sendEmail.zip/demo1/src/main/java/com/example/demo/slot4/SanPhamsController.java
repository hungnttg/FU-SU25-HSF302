package com.example.demo.slot4;

import com.example.demo.slot3.Slot3SanPham;
import com.example.demo.slot3.Slot3SanPhamRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/slot4") //localhost:8080/slot4
public class SanPhamsController {
    @Autowired
    private Slot3SanPhamRepository repository; //tham chieu den repository
    @GetMapping("/list") //localhost:8080/slot4/list
    public String list(Model model) {
        List<Slot3SanPham> sanPhams = repository.findAll();//lay ve tat ca cac san pham
        model.addAttribute("dssp", sanPhams);//gan san pham vao model dssp
        return "slot4/listproduct";//tra san pham ve giao dien slot4/listproduct.html
    }
    @GetMapping("/detail/{id}")
    public String detail(@PathVariable int id, Model model) {
        Optional<Slot3SanPham> sanPham = repository.findById(id);//lay ve 1 san pham
        if(sanPham.isPresent()) {//neu ton tai san pham
            model.addAttribute("sp", sanPham.get());//gan sanpham voi model sp
            return "slot4/detailproduct";//tra san pham ve cho giao dien detailproduct/html
        }
        else {
            return "redirect:/slot4/list"; //neu khong ton tai san pham => tra ve danh sach sp
        }


    }
}
