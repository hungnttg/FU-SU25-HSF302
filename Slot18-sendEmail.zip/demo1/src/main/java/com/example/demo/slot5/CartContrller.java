package com.example.demo.slot5;

import com.example.demo.demo3.Demo3SanPham;
import com.example.demo.demo3.Demo3SanPhamRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Controller //co giao dien
@RequestMapping("/cart")// localhost:8080/cart
@SessionAttributes("cart") //quan ly gio hang
public class CartContrller {
    @Autowired
    Demo3SanPhamRepository repo;
    //tao 1 gio hang blank
    @ModelAttribute("cart")
    public List<CartItem> cart() {
        return new ArrayList<>();
    }
    //them 1 san pham vao gio hang
    //can 3 tham so: id, so luong, gio hang
    @PostMapping("/add/{id}")//localhost:8080/cart/add/1
    public String add(@PathVariable int id,@RequestParam(defaultValue = "1") int sl,
                      @ModelAttribute("cart") List<CartItem> cart) {
        //lay ve id san pham
        Demo3SanPham sp = repo.findById(id).orElse(null);
        //kiem tra 3 truong hop
        //th1: null
        if(sp == null){
            return "redirect:/error";//bao loi
        }
        //th2: san pham da ton tai trong gio hang
        for(CartItem c : cart){
            if(c.getSanPham().getId() == id){
                c.setSoLuong(c.getSoLuong()+sl);//cong don so luong
                return  "redirect:/cart/view";//hien thi gio hang
            }
        }
        //th3: chua co san pham
        cart.add(new CartItem(sp,sl));//them sp vao gio hang
        return "redirect:/cart/view";//hien thi gio hang
    }
    //xem gio hang
    @GetMapping("/view")
    public String view(Model model,@ModelAttribute("cart") List<CartItem> cart) {
        model.addAttribute("cartItems", cart);//gan cartItems bang cart
        return "/slot5/cart";//tra ve trang cart.html
    }
    //update san pham trong goo hang
    //can 3 tham so:ma sp, so luong, gio hang
    @PostMapping("/update/{id}")
    public String update(@PathVariable int id,@RequestParam int sl,
                         @ModelAttribute("cart") List<CartItem> cart) {
        cart.forEach(c->{//duyet qua tung san pham
            if(c.getSanPham().getId() == id){//lay dung id can cap nhat
                c.setSoLuong(sl);//cap nhat so luong
            }
        });
        return "redirect:/cart/view";//hien thi gio hang
    }
    //xoa san pham trong gio hang
    @GetMapping("/remove/{id}")
    public String remove(@PathVariable int id,@ModelAttribute("cart") List<CartItem> cart) {
        cart.removeIf(c->c.getSanPham().getId() == id);//xoa co dieu kien
        return "redirect:/cart/view";//hien thi gio hang
    }
    @PostMapping("/checkout")
    public String checkout(@ModelAttribute("cart") List<CartItem> cart) {
        cart.clear();//xoa gio hang
        return "redirect:/cart/view";
    }
}
