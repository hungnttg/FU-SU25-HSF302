package com.example.demo.slot5;

import com.example.demo.demo3.Demo3SanPham;

public class CartItem {
    private Demo3SanPham sanPham;
    private int soLuong;

    public CartItem(Demo3SanPham sanPham, int soLuong) {
        this.sanPham = sanPham;
        this.soLuong = soLuong;
    }

    public Demo3SanPham getSanPham() {
        return sanPham;
    }

    public void setSanPham(Demo3SanPham sanPham) {
        this.sanPham = sanPham;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }
}
