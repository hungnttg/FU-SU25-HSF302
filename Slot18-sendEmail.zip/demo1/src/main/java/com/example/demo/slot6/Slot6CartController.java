package com.example.demo.slot6;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/slot6/cart")
public class Slot6CartController {
    @Autowired
    RedisTemplate<String,Object> redisTemplate;//tham chieu den Redis
    @Autowired
    Slot6SanPhamRepo repo;//tham chieu den repo
    String key="slot6cart";
    //them san pham vao gio hang
    @PostMapping("/add/{id}")
    public String add(@PathVariable int id){
        Slot6SanPham sp=repo.findById(id).orElse(null);//lay ve san pham theo id
        if(sp!=null){
            //them san pham vao redis
            redisTemplate.opsForHash().put(key,String.valueOf(sp.getId()),sp);
        }
        return "Da them: "+sp.getTensanpham(); //dua ra thong bao
    }
    //xem gio hang
    @GetMapping
    public List<Object> getAll(){
        return redisTemplate.opsForHash().values(key);
    }
    //xoa san pham trong gio hang
    @DeleteMapping("/remove/{id}")
    public String remove(@PathVariable int id){
        redisTemplate.opsForHash().delete(key,String.valueOf(id));
        return "Da xoa id "+id;
    }
    //xoa toan bo gio hang
    @DeleteMapping("/clear")
    public String clear(){
        redisTemplate.delete(key);
        return "Da xoa toan bo gio hang";
    }
//    Test API
//    Co the test tren postman (da huong dan)
//    test bang curl (su dung terminal hoac CMD tren window)
//    Them san pham
//    curl -X POST http://localhost:8083/api/slot6/cart/add/1
//    Xem gio hang
//    curl http://localhost:8083/api/slot6/cart
//    xoa 1 san pham trong gio hang
//    curl -X DELETE http://localhost:8083/api/slot6/cart/remove/1
//    xoa toan bo gio hang
//    curl -X DELETE http://localhost:8083/api/slot6/cart/clear

}
