package com.example.demo.slot61;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/api/slot61/cart")
public class Slot61SanPhamController {
    @Autowired
    private RedisTemplate<String,Object> restTemplate;
    @Autowired
    private Slot61SanPhamRepo repo;
    String key = "slot61cart";
    //them 1 san pham tu DB vao server redis
    @PostMapping("/add/{id}")
    public String add(@PathVariable int id) {
        //tao 1 san pham moi voi id cho truoc
        //luu y: id nay phai trung voi id trong bang du lieu
        Slot61SanPham sp = repo.findById(id).orElse(null);
        if(sp != null) {
            //lay du lieu tu DB dua vao server redis
            restTemplate.opsForHash().put(key,String.valueOf(id),sp);
            return "Da them: "+sp.getTensanpham();//dua ra thong bao
        }
        return "Khong tim thay san pham";
    }
    //hien thi tat ca cac san pham
    @GetMapping
    public List<Object> viewCart(){
        return restTemplate.opsForHash().values(key);
    }
    //xoa 1 san pham khoi regis
    @DeleteMapping("/remove/{id}")
    public String remove(@PathVariable int id) {
        restTemplate.opsForHash().delete(key,String.valueOf(id));
        return "Da xoa: "+id;
    }
    //xoa toan bo cac san pham khoi redis
    @DeleteMapping("/clear")
    public String clear() {
        restTemplate.delete(key);
        return "Da xoa: "+key;
    }
//    trieu goi API
//    su dung terminal (hoac cmd trong window)
//    insert du lieu tu bang du lieu vao redis
//    curl -X POST http://localhost:8083/api/slot61/cart/add/1
//    xoa 1 ban ghi trong redis
//    curl -X DELETE http://localhost:8083/api/slot61/cart/remove/1
//    xoa toan bo gio hang
//    curl -X DELETE http://localhost:8083/api/slot61/cart/clear
//    lay ta ca san pham trong redis
//    curl http://localhost:8083/api/slot61/cart
}
