package com.example.demo.slot61;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Slot61SanPhamRepo extends JpaRepository<Slot61SanPham, Integer> {
}
