package com.example.demo.slot7;

public class Slot7CartItem {
    private Integer id;
    private String tensanpham;
    private Double giasanpham;
    private Integer quantity;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTensanpham() {
        return tensanpham;
    }

    public void setTensanpham(String tensanpham) {
        this.tensanpham = tensanpham;
    }

    public Double getGiasanpham() {
        return giasanpham;
    }

    public void setGiasanpham(Double giasanpham) {
        this.giasanpham = giasanpham;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }
}
