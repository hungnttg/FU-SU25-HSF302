package com.example.demo.slot8;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class Slot8ProductService {
    private final Slot8ProductRepository repository;

    public Slot8ProductService(Slot8ProductRepository repository) {
        this.repository = repository;
    }

    public List<Slot8Product> getAllProducts() {
        return repository.findAll();
    }

    public Optional<Slot8Product> getProductById(Long id) {
        return repository.findById(id);
    }

    public Slot8Product saveProduct(Slot8Product product) {
        return repository.save(product);
    }

    public void deleteProduct(Long id) {
        repository.deleteById(id);
    }
}
