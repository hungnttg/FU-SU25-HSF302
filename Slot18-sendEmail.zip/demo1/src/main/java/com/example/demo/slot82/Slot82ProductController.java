package com.example.demo.slot82;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/slot82/products")
public class Slot82ProductController {
    //tham chieu den service
    private final Slot82ProductService productService;
    //ham khoi tao
    public Slot82ProductController(Slot82ProductService productService) {
        this.productService = productService;
    }
    //danh sach san pham
    @GetMapping
    public String listProducts(Model model) {
        //lay toan bo san pham va gan vao products
        model.addAttribute("products",productService.getAllProducts());
        return "slot82/product82-list";//hien thi tren giao dien
    }
    //them moi 1 san pham
    @GetMapping("/new")
    public String newProduct(Model model) {
        Slot82Product product = new Slot82Product();//tao 1 doi tuong moi
        model.addAttribute("product",product);//gan vao model
        return "slot82/product82-form";//moi form nhap lieu
    }
    //save san pham
    @PostMapping("/save")
    public String saveProduct(@ModelAttribute Slot82Product product, Model model, RedirectAttributes redirectAttr) {
        productService.saveProduct(product);//luu san pham
        //duu ra message khi thanh cong
        redirectAttr.addFlashAttribute("message","Product saved successfully");
        return "redirect:/slot82/products";//redirect den trang chu
    }
    //sua san pham
    @GetMapping("/edit/{id}")
    public String editProduct(@PathVariable("id") long id, Model model, RedirectAttributes redirectAttr) {
        var productOpt= productService.getProductById(id);//lay ve san pham theo id
        if(productOpt.isPresent()) {//neu ton tai san pham
            model.addAttribute("product",productOpt.get());//gan key la product
            return "slot82/product82-form";//moi form nhap lieu
        }
        else {//neu khong ton tai san pham
            redirectAttr.addFlashAttribute("error","Product not found");//loi
            return "redirect:/slot82/products";//redirect ve trang chu
        }

    }
    //xoa san pham
    @GetMapping("/delete/{id}")
    public String deleteProduct(@PathVariable("id") long id, RedirectAttributes redirectAttr) {
        productService.deleteProductById(id);//xoa san pham
        //dua ra thong bao
        redirectAttr.addFlashAttribute("message","Product deleted successfully");
        return "redirect:/slot82/products";//redirect ve trang chu
    }
//    goi ham
//    danh sach san pham: /slot82/products
//    them san pham moi: /slot82/products/new
//    sua san pham     : /slot82/products/edit/{id}
//    xoa san pham     :/slot82/product/delete/{id}
}
