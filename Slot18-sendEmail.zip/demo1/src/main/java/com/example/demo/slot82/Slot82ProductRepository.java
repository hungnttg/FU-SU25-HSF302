package com.example.demo.slot82;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Slot82ProductRepository extends JpaRepository<Slot82Product,Long> {
}
