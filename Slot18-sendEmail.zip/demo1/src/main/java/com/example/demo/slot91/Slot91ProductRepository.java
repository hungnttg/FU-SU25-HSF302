package com.example.demo.slot91;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface Slot91ProductRepository extends JpaRepository<Slot91Product, Long> {
    //tim kiem khong phan trang
    List<Slot91Product> findByNameContaining(String keyword);
    //tim kiem co phan trang
    Page<Slot91Product> findByNameContaining(String keyword, Pageable pageable);
}
