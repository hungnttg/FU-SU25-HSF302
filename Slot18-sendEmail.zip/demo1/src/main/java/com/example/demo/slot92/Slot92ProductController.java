package com.example.demo.slot92;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/slot92/products")
public class Slot92ProductController {
    @Autowired
    private Slot92ProductRepo repo;
    //lay san pham theo ID (truyen PathVariable)
    @GetMapping("/{id}")
    public ResponseEntity<Slot92Product> getById(@PathVariable Long id) {
        return repo.findById(id) //tim kiem theo ID va co 2 kha nang xay ra
                .map(ResponseEntity::ok) //tim thay thi tra ve Entity
                .orElse(ResponseEntity.notFound().build()); //khong tim thay -> thong bao
    }
    //tim kiem san pham khong phan trang (truyen RequestParam)
    @GetMapping("/search")
    public List<Slot92Product> search(@RequestParam String keyword) {
        return repo.findByNameContaining(keyword);//implement ham trong interface
    }
    //tim kiem san pham co phan trang
    @GetMapping("/searchPage")
    public Page<Slot92Product> searchPage(@RequestParam String keyword,
                                          @RequestParam(defaultValue = "0") int page,
                                          @RequestParam(defaultValue = "5") int size) {
        //implement ham trong interface
        return repo.findByNameContaining(keyword, PageRequest.of(page, size));

    }
    //cach goi:
    //http://localhost:8083/slot92/products/1 : tra ve san pham theo ID
    //http://localhost:8083/slot92/products/search?keyword=a : tim kiem khong phan trang
    //http://localhost:8083/slot92/products/searchPage?keyword=a&page=1&size=2 : tim kiem co phan trang
}
