package com.example.demoidea;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoideaApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoideaApplication.class, args);
    }

}
