package com.example.demoidea.slot1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/slot1/api")
public class EmployeeController {
    @Autowired
    private EmpolyeeRepository empolyeeRepository;
    @GetMapping("/high-salary")
    public List<Employee> getHighSalary() {
        return empolyeeRepository.findAll()
                .stream()
                .filter(nv->nv.getSalary()>3000)
                .collect(Collectors.toList());
    }
}
