package com.example.demoidea.slot1;

import org.springframework.data.jpa.repository.JpaRepository;

public interface EmpolyeeRepository extends JpaRepository<Employee, Long> {
}
