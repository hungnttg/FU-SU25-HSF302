package com.example.demoidea.slot2;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/slot2_1")
public class Slot2_1Controller {
    @GetMapping("/get")
    public String showForm(){
        return "slot2/form1";
    }
    @PostMapping("/post")
    public String saveStudent(@RequestParam String name,
                              @RequestParam String mark,
                              @RequestParam String major,
                              Model model){
        model.addAttribute("name", name);
        model.addAttribute("mark", mark);
        model.addAttribute("major", major);
        return "slot2/success1";
    }
}
