package com.example.demoidea;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoideaApplicationTests {

    @Test
    void contextLoads() {
    }

}
