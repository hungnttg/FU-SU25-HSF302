package com.example.demo.slot2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/slot2") //localhost:8080/slot2
public class EmployeeController {
    @Autowired //tham chieu
    private EmployeeRepository employeeRepository;
    @GetMapping("/high-salary") //localhost:8080/slot2/high-salary
    public List<Employee> getHighSalary() {
        return employeeRepository.findAll() //lay ve toan bo nhan vien
                .stream()
                .filter(emp -> emp.getSalary() >3000) //loc
        .collect(Collectors.toList());//chuyen thanh list
    }
}
