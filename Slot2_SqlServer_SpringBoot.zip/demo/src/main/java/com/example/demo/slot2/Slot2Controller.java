package com.example.demo.slot2;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/slot2")
public class Slot2Controller {
    @GetMapping("/form")
    public String showForm(Model model) {
        //thu thap du lieu va dua vao doi tuong student
        model.addAttribute("student", new Student());
        //goi den form.html
        return "slot2/form";
    }
    @PostMapping("/save")
    public String saveStudent(@ModelAttribute("student") Student student,Model model) {
        //truyen lai ket qua thu thap tu model sang view
        model.addAttribute("student", student);
        //goi den form nhan du lieu
        return "slot2/success";
    }
}
