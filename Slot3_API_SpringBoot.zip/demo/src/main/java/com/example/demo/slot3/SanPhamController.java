package com.example.demo.slot3;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/sanpham")
public class SanPhamController {
    @Autowired
    private final SanPhamRepository repo;

    public SanPhamController(SanPhamRepository repo) {
        this.repo = repo;
    }
    //lay ve toan bo sanpham
    @GetMapping
    public List<SanPham> getAll() {
        return repo.findAll();
    }
    //lay ve 1 san pham
    @GetMapping("/{id}")
    public Optional<SanPham> getById(@PathVariable int id) {
        return repo.findById(id);
    }
    //them moi 1 san pham
    @PostMapping
    public SanPham save(@RequestBody SanPham sanPham) {
        return repo.save(sanPham);
    }
    //sua 1 san pham
    @PutMapping("/{id}")
    public SanPham update(@PathVariable int id, @RequestBody SanPham sanPham) {
        sanPham.setId(id);
        return repo.save(sanPham);
    }
    //xoa san pham
    @DeleteMapping("/{id}")
    public void delete(@PathVariable int id) {
        repo.deleteById(id);
    }
    /*
    loi goi ham
    Lay ve sanh sach san pham
    http://localhost:8080/api/sanpham
    lay ve 1 san pham
    http://localhost:8080/api/sanpham/1
    them moi san pham
    POST: http://localhost:8080/api/sanpham (postman)
    sua san pham
    PUT: http://localhost:8080/api/sanpham/1 (postman)
    xoa san pham
    DELETE
    http://localhost:8080/api/sanpham/1 (postman)
    * */
}
