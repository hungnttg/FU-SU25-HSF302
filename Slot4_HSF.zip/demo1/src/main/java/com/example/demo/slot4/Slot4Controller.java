package com.example.demo.slot4;
import com.example.demo.slot3.SanPham;
import com.example.demo.slot3.SanPhamRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/slot4") //localhost:8081/slot4
public class Slot4Controller {
    @Autowired
    private SanPhamRepository repository; //tham chieu den repository
    @GetMapping("/list") //localhost:8081/slot4/list
    public String list(Model model) {
        List<SanPham> sanPhams = repository.findAll();//lay ve toan bo san pham trong bang sanpham
        //attach model
        model.addAttribute("dssp", sanPhams);
        //tra ve giao dien
        return "slot4/listproduct";
    }
    @GetMapping("/detail/{id}") //localhost:8081/slot4/detail/1
    public String detail(@PathVariable Integer id, Model model) {
        Optional<SanPham> sanPham = repository.findById(id);//lay ve san pham theo id
        if(sanPham.isPresent()) {//neu ton tai san pham
            model.addAttribute("sp", sanPham.get());//attach chi tiet san pham voi model
            return "slot4/detailproduct";//goi den giao dien detailproduct.html
        }
        else {
            return "redirect:/slot4/list";//neu khong co san pham => tra ve danh sach san pham
        }
    }

}
