package com.example.demo.slot10_1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
@RequestMapping("/slot101/products")
public class Slot101ProductController {
    @Autowired
    Slot101ProductRepo repo;
    @GetMapping("/search")
    public String search(@RequestParam(required = false) String keyword, Model model) {
        List<Slot101Product> results = keyword != null && !keyword.isBlank() ?
                repo.findByNameContaining(keyword)
                : List.of();//tra ve rong neu chua nhap gi
        //add vao model
        model.addAttribute("keyword", keyword);
        model.addAttribute("results", results);
        return "slot101/sl101-products-search";
    }
    @GetMapping("/{id}")
    public String getProductById(@PathVariable Long id, Model model) {
        Slot101Product product = repo.findById(id).orElseThrow(
                ()->new Slot101ResourceNotFountException("Khong tim thay san pham co ID = "+id));
        model.addAttribute("product", product);//dua san pham vao model
        return "slot101/sl101-product-detail";
    }
//    cach goi
//    tim kiem: http://localhost:8083/slot101/products/search
//    http://localhost:8083/slot101/products/1
//    http://localhost:8083/slot101/products/1000
}
