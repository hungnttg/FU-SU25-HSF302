package com.example.demo.slot11;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
@Table(name = "users") // có thể dùng "user", nhưng user là từ khóa SQL nên tốt nhất dùng "users"
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Tên không được để trống")
    @Size(min = 2, message = "Tên phải có ít nhất 2 ký tự")
    private String name;

    @Min(value = 18, message = "Tuổi phải từ 18 trở lên")
    @Max(value = 65, message = "Tuổi phải nhỏ hơn 65")
    private int age;

    @Email(message = "Email không hợp lệ")
    private String email;

    public User() {
    }

    public User(Long id, String name, int age, String email) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.email = email;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
