package com.example.demo.slot5;

import com.example.demo.slot3.SanPham;
import com.example.demo.slot3.SanPhamRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Controller //goi den trang khac
@RequestMapping("/cart")//localhost:8083/cart
@SessionAttributes("cart") //session ten la cart
public class CartController {
    @Autowired
    SanPhamRepository repo; //tham chieu den repo
    //tao model gio hang
    @ModelAttribute("cart")
    public List<CartItem> cart(){
        return new ArrayList<>();
    }
    //them san pham vao gio hang
    //truyen 3 tham so: id, so luong, list gio hang
    @PostMapping("/add/{id}")
    public String add(@PathVariable int id,@RequestParam(defaultValue = "1") int quantity,
                      @ModelAttribute("cart") List<CartItem> cart){
        SanPham sp=repo.findById(id).orElse(null);//lay ve san pham theo id
        //TH1: xu ly khi san pham la null
        if(sp==null) return "redirect:/error";
        //TH2.neu khong null
        for(CartItem c:cart)
            //neu trong gio hang da ton tai san pham
           if(c.getSanPham().getId()== id) {
               c.setQuantity(c.getQuantity()+quantity);//cong don so luong
               return "redirect:/cart/view"; //tra ve view gio hang
           }
        //TH3.neu chua ton tai ma san pham
        cart.add(new CartItem(sp,quantity));//tao 1 item moi trong gio hang
        return "redirect:/cart/view";//hien thi gio hang
    }
    @GetMapping("/view") //xem gio hang
    public String viewModel(Model model,@ModelAttribute("cart") List<CartItem> cart){
        model.addAttribute("cartItem",cart);//gan model voi cart
        return "slot5/cart"; //hien thi
    }
    //cap nhat gio hang
    //can 3 tham so: id san pham can cap nhat, so luong cap nhat, gio hang
    @PostMapping("/update/{id}")
    public String update(@PathVariable int id,@RequestParam int quantity,
                         @ModelAttribute("cart") List<CartItem> cart){
        cart.forEach(c->{
            if(c.getSanPham().getId()==id){ //tim id can cap nhat trong gio hang
                c.setQuantity(quantity);//thiet lap so luong
            }
        });
        return "redirect:/cart/view";//hien thi lai gio hang sau cap nhat
    }
    //xoa san pham trong gio hang
    @GetMapping("/remove/{id}")
    public String remove(@PathVariable int id,@ModelAttribute("cart") List<CartItem> cart){
        cart.removeIf(c->c.getSanPham().getId()==id);//tim id va xoa
        return "redirect:/cart/view";//hien thi lai gio hang
    }
    //checkout
    @PostMapping("/checkout")
    public String checkout(@ModelAttribute("cart") List<CartItem> cart){
        cart.clear();//xoa
        return "redirect:/cart/view";
    }
}
