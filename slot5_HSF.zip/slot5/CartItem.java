package com.example.demo.slot5;

import com.example.demo.slot3.SanPham;

//quan ly cac item (cac san pham duoc them vao gio hang)
public class CartItem {
    private SanPham sanPham;
    private int quantity;

    public CartItem() {
    }

    public CartItem(SanPham sanPham, int quantity) {
        this.sanPham = sanPham;
        this.quantity = quantity;
    }

    public SanPham getSanPham() {
        return sanPham;
    }

    public void setSanPham(SanPham sanPham) {
        this.sanPham = sanPham;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
